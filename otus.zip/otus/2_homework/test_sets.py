"""
Проверить, что set пустой
"""


def test_sets(sets):
    print(sets)
    assert sets is None
